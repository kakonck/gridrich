Gridrich 1.0.0 charts, 2026-09-27.
SVG: vector, editable in Inkscape, Illustrator or PowerPoint.
Grid: 10km. Titles are embedded in each image.
