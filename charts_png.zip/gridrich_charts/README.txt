Gridrich 1.0.0 charts, 2026-09-27.
PNG: 3000 px wide, white background.
Grid: 10km. Titles are embedded in each image.
